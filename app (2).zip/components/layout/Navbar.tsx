"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const navItems = [
  { label: "Home", href: "/" },
  { label: "Sobre", href: "/sobre" },
  { label: "Setup", href: "/setup" },
  { label: "Portfólio", href: "/portfolio" },
  { label: "Conquistas", href: "/conquistas" },
];

export default function Navbar() {
  const pathname = usePathname();

  return (
    <>
      <header className="fixed inset-x-0 top-0 z-[100] px-4 pt-3 md:px-6">
        <div className="mx-auto max-w-[1240px]">
          <div className="navbar-shell soft-float rounded-[28px] border border-white/10 bg-black/55 px-5 py-3 shadow-[0_12px_40px_rgba(0,0,0,0.28)] backdrop-blur-xl">
            <div className="grid grid-cols-[auto_1fr] items-center gap-6">
              <Link href="/" className="group flex items-center gap-3">
                <div className="navbar-logo-wrap h-10 w-10 rounded-[16px]">
                  <div className="navbar-logo-core h-full w-full rounded-[16px] bg-[linear-gradient(135deg,rgba(225,29,72,0.85),rgba(212,175,55,0.55))]" />
                </div>

                <div className="leading-none">
                  <p className="text-[10px] uppercase tracking-[0.32em] text-zinc-400">
                    Premium Profile
                  </p>
                  <p className="mt-1 text-[18px] font-black tracking-[0.2em] text-white">
                    NEED
                  </p>
                </div>
              </Link>

              <nav className="hidden items-center justify-center gap-8 lg:flex xl:gap-10">
                {navItems.map((item) => {
                  const isActive = pathname === item.href;

                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={[
                        "nav-link-smooth text-sm transition",
                        isActive
                          ? "text-white"
                          : "text-zinc-200 hover:text-white",
                      ].join(" ")}
                    >
                      {item.label}
                    </Link>
                  );
                })}
              </nav>
            </div>
          </div>
        </div>
      </header>

      <div className="h-[96px] md:h-[104px]" />
    </>
  );
}                     