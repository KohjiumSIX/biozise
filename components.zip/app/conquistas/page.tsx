import InnerPageShell from "@/components/layout/InnerPageShell";
import { Trophy } from "lucide-react";

const achievements = [
  "Construindo evolução contínua entre gameplay, performance e conteúdo.",
  "Página pessoal premium com navegação real entre rotas.",
  "Base pronta para expandir com highlights, redes, setup e projetos.",
  "Estrutura separada por páginas, mantendo a home limpa e principal.",
];

export default function ConquistasPage() {
  return (
    <InnerPageShell
      eyebrow="Conquistas"
      title="Marcos e evolução"
      description="Espaço para destacar progresso, estrutura construída e próximos passos."
    >
      <div className="grid gap-4 md:grid-cols-2">
        {achievements.map((item) => (
          <div
            key={item}
            className="rounded-[24px] border border-white/10 bg-white/[0.04] p-5"
          >
            <div className="flex items-start gap-3">
              <div className="mt-1 rounded-full border border-white/10 bg-black/20 p-2 text-amber-300">
                <Trophy size={15} />
              </div>

              <p className="text-sm leading-7 text-zinc-300">{item}</p>
            </div>
          </div>
        ))}
      </div>
    </InnerPageShell>
  );
}                                 