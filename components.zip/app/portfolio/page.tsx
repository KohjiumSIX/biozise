import Link from "next/link";
import InnerPageShell from "@/components/layout/InnerPageShell";
import { ExternalLink, FolderKanban } from "lucide-react";

const items = [
  {
    title: "Perfil premium / landing page",
    description:
      "Página principal com identidade visual, navegação premium e foco em presença digital.",
    href: "/",
  },
  {
    title: "Página de Valorant",
    description:
      "Área dedicada para highlights, configs, setup e conteúdo relacionado ao jogo.",
    href: "/jogos/valorant",
  },
  {
    title: "Página de LoL",
    description:
      "Área dedicada para perfil, destaques, configs e organização de conteúdo por jogo.",
    href: "/jogos/lol",
  },
];

export default function PortfolioPage() {
  return (
    <InnerPageShell
      eyebrow="Portfólio"
      title="Projetos e páginas"
      description="Uma vitrine das páginas e estruturas principais do site."
    >
      <div className="grid gap-4 lg:grid-cols-3">
        {items.map((item) => (
          <Link key={item.title} href={item.href}>
            <div className="rounded-[24px] border border-white/10 bg-white/[0.04] p-5 transition hover:border-white/20 hover:bg-white/[0.06]">
              <div className="flex items-center justify-between">
                <div className="rounded-2xl border border-white/10 bg-black/20 p-3 text-white">
                  <FolderKanban size={18} />
                </div>

                <ExternalLink size={16} className="text-zinc-500" />
              </div>

              <h2 className="mt-4 text-lg font-semibold text-white">
                {item.title}
              </h2>

              <p className="mt-2 text-sm leading-7 text-zinc-300">
                {item.description}
              </p>
            </div>
          </Link>
        ))}
      </div>
    </InnerPageShell>
  );
}