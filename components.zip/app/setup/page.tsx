import InnerPageShell from "@/components/layout/InnerPageShell";
import { Cpu, Keyboard, Monitor, Mouse } from "lucide-react";

export default function SetupPage() {
  return (
    <InnerPageShell
      eyebrow="Setup"
      title="Meu setup"
      description="Hardware, periféricos e base principal que uso no dia a dia."
    >
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-[24px] border border-white/10 bg-white/[0.04] p-5">
          <div className="flex items-center gap-2 text-white">
            <Cpu size={16} />
            <span className="font-medium">PC</span>
          </div>
          <p className="mt-3 text-sm leading-7 text-zinc-300">
            Ryzen 7 7800X3D • RTX 4070 Super • 32 GB DDR5
          </p>
        </div>

        <div className="rounded-[24px] border border-white/10 bg-white/[0.04] p-5">
          <div className="flex items-center gap-2 text-white">
            <Monitor size={16} />
            <span className="font-medium">Monitor</span>
          </div>
          <p className="mt-3 text-sm leading-7 text-zinc-300">AOC 300 Hz</p>
        </div>

        <div className="rounded-[24px] border border-white/10 bg-white/[0.04] p-5">
          <div className="flex items-center gap-2 text-white">
            <Mouse size={16} />
            <span className="font-medium">Mouse</span>
          </div>
          <p className="mt-3 text-sm leading-7 text-zinc-300">
            Logitech x2 Superstrike • Artisan FX Zero Soft
          </p>
        </div>

        <div className="rounded-[24px] border border-white/10 bg-white/[0.04] p-5">
          <div className="flex items-center gap-2 text-white">
            <Keyboard size={16} />
            <span className="font-medium">Teclado</span>
          </div>
          <p className="mt-3 text-sm leading-7 text-zinc-300">
            Mchose Ace 68
          </p>
        </div>
      </div>
    </InnerPageShell>
  );
}