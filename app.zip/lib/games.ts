export type GamePageData = {
  slug: string;
  title: string;
  eyebrow: string;
  description: string;
  accentClass: string;
  heroVideo: string;
  stats: {
    label: string;
    value: string;
  }[];
  highlights: {
    title: string;
    description: string;
  }[];
  config: {
    label: string;
    value: string;
  }[];
  links: {
    label: string;
    href: string;
  }[];
};

export const gamesData: Record<string, GamePageData> = {
  valorant: {
    slug: "valorant",
    title: "Valorant",
    eyebrow: "Competitive FPS",
    description:
      "Minha página dedicada ao Valorant, com highlights, configs, sensibilidade, setup e tudo que uso para competir e evoluir.",
    accentClass: "game-page-red",
    heroVideo: "/games/valorant.mp4",
    stats: [
      { label: "Focus", value: "Precision Flick" },
      { label: "Role", value: "Duelist" },
      { label: "Style", value: "Aggressive Control" },
      { label: "Content", value: "Highlights + Settings" },
    ],
    highlights: [
      {
        title: "Highlights",
        description:
          "Espaço para colocar seus melhores clutches, flicks, plays de ranked e vídeos curtos.",
      },
      {
        title: "Sensibilidade",
        description:
          "Área para mostrar DPI, sens, polling rate, resolução e outros detalhes da sua config.",
      },
      {
        title: "Setup",
        description:
          "Lugar para mouse, mousepad, monitor, teclado, headset e periféricos usados no game.",
      },
    ],
    config: [
      { label: "DPI", value: "1600" },
      { label: "Sens", value: "0.19" },
      { label: "HZ", value: "300Hz" },
      { label: "Resolution", value: "Adicionar" },
      { label: "Crosshair", value: "Adicionar" },
      { label: "Main Agent", value: "Adicionar" },
    ],
    links: [
      { label: "YouTube Highlights", href: "#" },
      { label: "Tracker / Stats", href: "#" },
      { label: "Twitch Lives", href: "#" },
    ],
  },

  lol: {
    slug: "lol",
    title: "League of Legends",
    eyebrow: "MOBA",
    description:
      "Minha página dedicada ao LoL, com perfil, momentos marcantes, builds, setup e conteúdo do jogo.",
    accentClass: "game-page-gold",
    heroVideo: "/games/lol.mp4",
    stats: [
      { label: "Focus", value: "Macro + Mechanics" },
      { label: "Role", value: "Adicionar" },
      { label: "Style", value: "Adicionar" },
      { label: "Content", value: "Highlights + Builds" },
    ],
    highlights: [
      {
        title: "Highlights",
        description:
          "Lugar para colocar plays, pentas, engages, outplays e melhores momentos.",
      },
      {
        title: "Builds / Config",
        description:
          "Área para runas, campeões principais, atalhos, câmera, HUD e preferências.",
      },
      {
        title: "Setup",
        description:
          "Seção para mostrar o setup e como ele se conecta com sua forma de jogar.",
      },
    ],
    config: [
      { label: "Main Role", value: "Adicionar" },
      { label: "Main Champions", value: "Adicionar" },
      { label: "Quick Cast", value: "Adicionar" },
      { label: "Resolution", value: "Adicionar" },
      { label: "HUD Scale", value: "Adicionar" },
      { label: "Server", value: "Adicionar" },
    ],
    links: [
      { label: "YouTube Highlights", href: "#" },
      { label: "OP.GG / Stats", href: "#" },
      { label: "Twitch Lives", href: "#" },
    ],
  },
};

export function getGameBySlug(slug: string) {
  return gamesData[slug];
}