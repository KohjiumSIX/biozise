import InnerPageShell from "@/components/layout/InnerPageShell";

const projects = [
  {
    name: "ProAcademy",
    status: "Em andamento",
    description:
      "Plataforma focada em evolução de performance para jogadores competitivos, com análise de gameplay, treinos personalizados e melhoria contínua baseada em dados e assistencia de IA.",
  },
  {
    name: "FairPlayAC",
    status: "Em desenvolvimento",
    description:
      "Anticheat em kernel mode desenvolvido para proteger servidores e jogos terceirizados, com foco em detecção avançada, integridade do sistema e prevenção de exploits.",
  },
];

function ProjectCard({
  name,
  status,
  description,
}: {
  name: string;
  status: string;
  description: string;
}) {
  return (
    <div className="group rounded-[24px] border border-white/10 bg-white/[0.03] p-6 transition-all duration-300 hover:border-white/15 hover:bg-white/[0.05] hover:-translate-y-1 hover:shadow-[0_20px_80px_rgba(0,0,0,0.4)]">
      
      {/* HEADER */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">{name}</h2>

        <span className="rounded-full bg-orange-400/10 px-3 py-1 text-xs font-semibold text-orange-400 border border-orange-400/20">
          {status}
        </span>
      </div>

      {/* DESCRIPTION */}
      <p className="mt-4 text-sm leading-6 text-zinc-400">
        {description}
      </p>

      {/* ACTION */}
      <div className="mt-6">
        <button className="w-full rounded-xl border border-orange-400/20 bg-orange-400/10 px-4 py-3 text-sm font-medium text-orange-300 transition-all duration-300 hover:bg-orange-400/20 hover:text-orange-200 hover:shadow-[0_0_20px_rgba(255,150,0,0.2)]">
          Apoiar projeto
        </button>
      </div>
    </div>
  );
}

export default function PortfolioPage() {
  return (
    <InnerPageShell
      eyebrow="Portfolio"
      title="Projetos"
      description="Projetos em desenvolvimento focados em performance, tecnologia e experiência competitiva."
    >
      <section className="grid gap-6 md:grid-cols-2">
        {projects.map((project) => (
          <ProjectCard key={project.name} {...project} />
        ))}
      </section>
    </InnerPageShell>
  );
}