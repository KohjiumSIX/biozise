import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ExternalLink, Play, Settings2, Monitor } from "lucide-react";
import { getGameBySlug, gamesData } from "@/lib/games";

type GamePageProps = {
  params: Promise<{
    slug: string;
  }>;
};

export function generateStaticParams() {
  return Object.keys(gamesData).map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: GamePageProps) {
  const { slug } = await params;
  const game = getGameBySlug(slug);

  if (!game) {
    return {
      title: "Jogo não encontrado",
    };
  }

  return {
    title: `${game.title} | NEED`,
    description: game.description,
  };
}

export default async function GamePage({ params }: GamePageProps) {
  const { slug } = await params;
  const game = getGameBySlug(slug);

  if (!game) {
    notFound();
  }

  return (
    <main className="page-micro-enter relative min-h-screen overflow-hidden bg-[#050505] text-white">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(225,29,72,0.12),transparent_30%),radial-gradient(circle_at_bottom_right,rgba(212,175,55,0.08),transparent_25%)]" />

      <div className="container-custom relative z-10 py-8">
        <div className="mb-6">
          <Link
            href="/"
            className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-4 py-2 text-sm text-zinc-200 transition hover:border-white/20 hover:bg-white/[0.07] hover:text-white"
          >
            <ArrowLeft size={16} />
            Voltar para home
          </Link>
        </div>

        <section
          className={`relative overflow-hidden rounded-[32px] border border-white/10 bg-white/[0.04] p-6 md:p-8 ${game.accentClass}`}
        >
          <div className="game-page-ambient absolute inset-0" />

          <div className="relative z-10 grid gap-8 lg:grid-cols-[1.05fr_0.95fr]">
            <div>
              <p className="text-xs uppercase tracking-[0.28em] text-zinc-400">
                {game.eyebrow}
              </p>

              <h1 className="mt-3 text-4xl font-black tracking-tight text-white md:text-5xl">
                {game.title}
              </h1>

              <p className="mt-4 max-w-[680px] text-[15px] leading-7 text-zinc-300">
                {game.description}
              </p>

              <div className="mt-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                {game.stats.map((item) => (
                  <div
                    key={item.label}
                    className="rounded-[22px] border border-white/10 bg-black/25 px-4 py-4 backdrop-blur-sm"
                  >
                    <p className="text-[11px] uppercase tracking-[0.2em] text-zinc-500">
                      {item.label}
                    </p>
                    <p className="mt-2 text-sm font-semibold text-white">
                      {item.value}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative overflow-hidden rounded-[28px] border border-white/10 bg-black/30">
              <video
                src={game.heroVideo}
                autoPlay
                loop
                muted
                playsInline
                className="h-full min-h-[320px] w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/35 to-black/5" />

              <div className="absolute bottom-5 left-5 right-5 flex items-end justify-between gap-4">
                <div>
                  <p className="text-sm text-zinc-300">Página do jogo</p>
                  <p className="mt-1 text-xl font-bold text-white">
                    Highlights, configs e setup
                  </p>
                </div>

                <div className="rounded-full border border-white/15 bg-black/45 p-3 text-white backdrop-blur-md">
                  <Play size={18} />
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="mt-6 grid gap-6 lg:grid-cols-[1fr_0.95fr]">
          <div className="rounded-[30px] border border-white/10 bg-white/[0.04] p-6">
            <div className="mb-5 flex items-center gap-3">
              <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-white">
                <Play size={18} />
              </div>
              <div>
                <p className="text-xs uppercase tracking-[0.22em] text-zinc-500">
                  Conteúdo
                </p>
                <h2 className="mt-1 text-2xl font-bold text-white">
                  Highlights e sessões
                </h2>
              </div>
            </div>

            <div className="grid gap-4">
              {game.highlights.map((item) => (
                <div
                  key={item.title}
                  className="rounded-[24px] border border-white/10 bg-black/20 p-5"
                >
                  <h3 className="text-lg font-semibold text-white">{item.title}</h3>
                  <p className="mt-2 text-sm leading-6 text-zinc-300">
                    {item.description}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="grid gap-6">
            <div className="rounded-[30px] border border-white/10 bg-white/[0.04] p-6">
              <div className="mb-5 flex items-center gap-3">
                <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-white">
                  <Settings2 size={18} />
                </div>
                <div>
                  <p className="text-xs uppercase tracking-[0.22em] text-zinc-500">
                    Config
                  </p>
                  <h2 className="mt-1 text-2xl font-bold text-white">
                    Informações principais
                  </h2>
                </div>
              </div>

              <div className="grid gap-3">
                {game.config.map((item) => (
                  <div
                    key={item.label}
                    className="flex items-center justify-between rounded-[20px] border border-white/10 bg-black/20 px-4 py-3"
                  >
                    <span className="text-sm text-zinc-400">{item.label}</span>
                    <span className="text-sm font-semibold text-white">
                      {item.value}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-[30px] border border-white/10 bg-white/[0.04] p-6">
              <div className="mb-5 flex items-center gap-3">
                <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-white">
                  <Monitor size={18} />
                </div>
                <div>
                  <p className="text-xs uppercase tracking-[0.22em] text-zinc-500">
                    Links
                  </p>
                  <h2 className="mt-1 text-2xl font-bold text-white">
                    Acessos rápidos
                  </h2>
                </div>
              </div>

              <div className="grid gap-3">
                {game.links.map((item) => (
                  <Link
                    key={item.label}
                    href={item.href}
                    className="group flex items-center justify-between rounded-[20px] border border-white/10 bg-black/20 px-4 py-3 text-sm text-zinc-200 transition hover:border-white/20 hover:bg-black/30 hover:text-white"
                  >
                    <span>{item.label}</span>
                    <ExternalLink
                      size={16}
                      className="transition group-hover:translate-x-[2px] group-hover:-translate-y-[2px]"
                    />
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}